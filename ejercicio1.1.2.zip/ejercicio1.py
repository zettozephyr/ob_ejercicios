numero_inicial = 4
numero_final = 11

for impares in range(numero_inicial, numero_final):
    if impares % 2 == 1:
        print(impares)
